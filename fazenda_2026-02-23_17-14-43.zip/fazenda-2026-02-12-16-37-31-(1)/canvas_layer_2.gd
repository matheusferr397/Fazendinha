extends CanvasLayer

# O erro acontece aqui se o nome após o $ não for EXATAMENTE o nome do seu Label
@onready var label_lixo = get_node("Label") # Tente usar o nome real do seu nó aqui

func _ready() -> void:
	# Verificação de segurança: se o Label for nulo, ele avisa no console
	if label_lixo == null:
		print("ERRO: O script não encontrou o nó Label. Verifique o nome na árvore de cenas!")
		return
		
	Dados.lixo_alterado.connect(_on_lixo_alterado)
	label_lixo.text = "Lixo Coletado: 0"

func _on_lixo_alterado(novo_valor: int) -> void:
	if label_lixo != null:
		label_lixo.text = "Lixo Coletado: " + str(novo_valor)
