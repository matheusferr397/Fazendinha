extends Node

signal semente_alterada(nova_quantidade)

var semente: int = 0

# Goal system
var target: int = 5
var time_limit: float = 160.0

var running: bool = false
var elapsed_time: float = 0.0
var grown: int = 0

var _hud: CanvasLayer = null
var _label_time: Label = null
var _label_progress: Label = null

func _ready() -> void:
	set_process(true)
	# inicia o objetivo automaticamente quando o jogo começa
	start_goal()

# --- seed management ---
func add_semente(qtd: int = 1) -> void:
	semente = max(0, semente + qtd)
	emit_signal("semente_alterada", semente)

func use_semente(qtd: int = 1) -> bool:
	if semente >= qtd:
		semente -= qtd
		emit_signal("semente_alterada", semente)
		return true
	return false

func set_semente(qtd: int) -> void:
	semente = max(0, qtd)
	emit_signal("semente_alterada", semente)

func get_semente() -> int:
	return semente

# --- goal functions ---
func start_goal() -> void:
	if running:
		return
	running = true
	elapsed_time = 0.0
	grown = 0
	_create_hud()
	_update_hud()

func tomato_grown() -> void:
	if not running:
		return
	grown += 1
	_update_hud()
	if grown >= target:
		_win()

func _process(delta: float) -> void:
	# goal timer: acumula delta para contar tempo (compatível com todas as versões)
	if not running:
		return
	elapsed_time += delta
	var remaining = time_limit - elapsed_time
	_update_time_label(max(0.0, remaining))
	if remaining <= 0.0:
		_lose()

func _create_hud() -> void:
	if _hud and _hud.is_inside_tree():
		return
	_hud = CanvasLayer.new()
	_hud.name = "GoalHUD"
	get_tree().root.add_child(_hud)

	var margin = 10
	var ctrl = Control.new()
	# fixe o controle no canto superior-esquerdo e posicione com rect_position
	ctrl.anchor_left = 0.0
	ctrl.anchor_top = 0.0
	ctrl.position = Vector2(margin, margin)
	_hud.add_child(ctrl)

	_label_time = Label.new()
	_label_time.name = "TimeLabel"
	_label_time.text = "Tempo: --"
	ctrl.add_child(_label_time)

	_label_progress = Label.new()
	_label_progress.name = "ProgressLabel"
	_label_progress.text = "Tomates: 0/%d" % target
	_label_progress.position = Vector2(0, 20)
	ctrl.add_child(_label_progress)

func _update_hud() -> void:
	if _label_progress:
		_label_progress.text = "Tomates: %d/%d" % [grown, target]

func _update_time_label(remaining: float) -> void:
	if _label_time:
		var sec = int(ceil(remaining))
		var mm = int(sec / 60)
		var ss = sec % 60
		_label_time.text = "Tempo: %02d:%02d" % [mm, ss]

func _show_fullscreen_message(text: String, color: Color) -> void:
	var overlay = ColorRect.new()
	overlay.color = color
	overlay.rect_min_size = Vector2(1,1)
	overlay.anchor_left = 0.0
	overlay.anchor_top = 0.0
	overlay.anchor_right = 1.0
	overlay.anchor_bottom = 1.0
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP

	var label = Label.new()
	label.text = text
	# deixa o texto grande e legível
	label.add_theme_font_size_override("font_size", 48)
	# cor clara para aparecer sobre o overlay escuro/ colorido
	if label.has_method("add_theme_color_override"):
		label.add_theme_color_override("font_color", Color(1,1,1,1))
	# usar enums corretos do Godot 4
	label.anchor_left = 0.0
	label.anchor_top = 0.0
	label.anchor_right = 1.0
	label.anchor_bottom = 1.0
	overlay.add_child(label)

	# adiciona o overlay ao HUD (CanvasLayer) se existir para garantir que fique acima
	if _hud and _hud.is_inside_tree():
		_hud.add_child(overlay)
	else:
		get_tree().root.add_child(overlay)

func _win() -> void:
	running = false
	_show_fullscreen_message("VITÓRIA!", Color(0,0.5,0,0.9))

func _lose() -> void:
	running = false
	_show_fullscreen_message("GAME OVER", Color(0.5,0,0,0.9))
