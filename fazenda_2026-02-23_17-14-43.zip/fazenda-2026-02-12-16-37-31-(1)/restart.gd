extends Node # <--- ESSA LINHA É OBRIGATÓRIA

func _lose() -> void:
	# 1. Criamos um CanvasLayer (camada de UI que fica acima de tudo)
	var hud_morte = CanvasLayer.new()
	
	# Agora o get_tree() vai funcionar porque herdamos de Node
	get_tree().root.add_child(hud_morte)

	# 2. Fundo Escuro
	var overlay = ColorRect.new()
	overlay.color = Color(0.5, 0, 0, 0.7)
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud_morte.add_child(overlay)

	# 3. Texto de Game Over
	var label = Label.new()
	label.text = "FIM DE JOGO"
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	hud_morte.add_child(label)

	# 4. Botão de Reiniciar
	var btn = Button.new()
	btn.text = "Tentar Novamente"
	btn.custom_minimum_size = Vector2(200, 50)
	btn.anchors_preset = Control.PRESET_CENTER # Centraliza no meio da tela
	
	# Conecta o clique para recarregar a fase
	btn.pressed.connect(func(): get_tree().reload_current_scene())
	
	hud_morte.add_child(btn)
