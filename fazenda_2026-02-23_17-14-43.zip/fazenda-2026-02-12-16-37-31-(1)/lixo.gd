extends Area2D

func _on_body_entered(body: Node2D) -> void:
	if body.name == "personagem":
		coletar()

func coletar() -> void:
	# 1. Avisa o Global (isso vai disparar o sinal que o CanvasLayer2 está ouvindo)
	Dados.add_lixo(1)
	
	# 2. Desaparece e reaparece (seu código original)
	visible = false
	set_deferred("monitoring", false)
	await get_tree().create_timer(10.0).timeout
	visible = true
	set_deferred("monitoring", true)
